using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Observer : MonoBehaviour
{
    public List<entity_component> entities;
    // Start is called before the first frame update
    void Awake()
    {
        entities = new List<entity_component>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Fire1")) {
            foreach (entity_component entity in entities)
            {
                Debug.Log(entity.Report());
            }
        }
        if (Input.GetButtonDown("Fire2"))
        {
            entities[0].RemoveCondition(typeof(slimed));
        }
    }
}
