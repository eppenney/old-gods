using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Concrete Decorator 
public class slimed : entity_decorator
{
    // Constructor 
    public slimed(entity_component targ)
    {
        child = targ;
        child.parent = this;
        observer.entities[observer.entities.IndexOf(child)] = this;
    }

    // Attributes for Gameplay 
    public int HP { get; set; }

    // Methods for Gameplay 


    // Attributes for Management
    public Observer observer { get { return child.observer; } set { child.observer = value; } }
    public entity_component child { get; set; }
    public entity_decorator parent { get; set; }


    // Methods for Management
    public string Report()
    {
        return child.Report() + " I am slimed!";
    }

    public void RemoveCondition(System.Type type)
    {
        if (type == typeof(slimed))
        {
            if (parent != null)
            {
                parent.child = child;
                child.parent = parent;
            } else
            {
                observer.entities[observer.entities.IndexOf(this)] = child;
                child.parent = null;
            }
        }
        else
        {
            child.RemoveCondition(type);
        }
    }
}
