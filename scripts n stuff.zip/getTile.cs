using System.Collections;
using System.Collections.Generic;
using UnityEngine.Tilemaps;
using UnityEngine;

public class Tile {
    public string name {get;set;}
    public float defendMultiplier {get; set;}
    public float evadeMultiplier {get;set;}
    public float moveMultiplier {get;set;} 
    public int damagePerRound {get;set;}
    public int xPos {get;set;}
    public int yPos{get;set;}

    public Tile(string tileName, int x, int y, float defX, float evaX, float moveX, int dpr) {
        name = tileName;
        defendMultiplier = defX;
        evadeMultiplier = evaX;
        moveMultiplier = moveX;
        damagePerRound = dpr;
        xPos = x;
        yPos = y;
    }
}

public class getTile : MonoBehaviour
{
    public Tilemap tileMap;
    private Camera cam;
    public float speed;
    public GameObject prefab;

    void Start()
    {
        cam = Camera.main;

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Fire1")) {
            Vector3Int pos = Vector3Int.FloorToInt(cam.ScreenToWorldPoint(Input.mousePosition));
            pos.z = 0;
            Debug.Log(GetTile(pos.x, pos.y).name);
            foreach (Tile item in GetAllPossibleTiles(pos.x, pos.y, 4)){
                Instantiate(prefab, new Vector3(item.xPos, item.yPos, 0), Quaternion.identity);
            }
        }
    } 

    public Tile GetTile(float x, float y) {
        Vector3Int pos = Vector3Int.FloorToInt(new Vector3(x, y, 0f));
        if (tileMap.HasTile(pos)) { 
            string name = tileMap.GetTile(pos).name;
            string[] names = name.Split('_');
            name = names[0];
            int num = int.Parse(names[1]);
            if (name == "TX Tileset Grass") {
                if (num < 32) {
                    return new Tile("Grass", pos.x, pos.y, 1, 1, 1, 0);        
                }
                else {
                    return  new Tile("Stone Path", pos.x, pos.y, 1, 1, 1, 0);
                }
            }
        }
        return null;
    }

    public List<Tile> GetAllPossibleTiles(float xPos, float yPos, int moveSpeed) {
        List<Tile> visitedTiles = new List<Tile>();
        List<Tile> queue = new List<Tile>();
        Tile t = GetTile(xPos, yPos);
        visitedTiles.Add(t);
        queue.Add(t);
        int counter = 0;
        while (queue.Count > 0) {
            counter++;
            if (counter > 500) {
                Debug.Log("Fuck");
                break;
            }
            Tile currPoint = queue[0];
            queue.RemoveAt(0);
            t = GetTile(currPoint.xPos + 1f, currPoint.yPos);
            if (t != null && Mathf.Abs(xPos - t.xPos) + Mathf.Abs(yPos - t.yPos) <= moveSpeed && !DoesContain(visitedTiles, t)) {
                queue.Add(t);
                visitedTiles.Add(t);
            }
            t = GetTile(currPoint.xPos - 1f, currPoint.yPos);
            if (t != null && Mathf.Abs(xPos - t.xPos) + Mathf.Abs(yPos - t.yPos) <= moveSpeed && !DoesContain(visitedTiles, t)) {
                queue.Add(t);
                visitedTiles.Add(t);
            }
            
            t = GetTile(currPoint.xPos, currPoint.yPos + 1f);
            if (t != null && Mathf.Abs(xPos - t.xPos) + Mathf.Abs(yPos - t.yPos) <= moveSpeed && !DoesContain(visitedTiles, t)) {
                queue.Add(t);
                visitedTiles.Add(t);
            }
            t = GetTile(currPoint.xPos, currPoint.yPos - 1f);
            if (t != null && Mathf.Abs(xPos - t.xPos) + Mathf.Abs(yPos - t.yPos) <= moveSpeed && !DoesContain(visitedTiles, t)) {
                queue.Add(t);
                visitedTiles.Add(t);
            }
        }
        
        return visitedTiles;
    }

    private bool DoesContain(List<Tile> tiles, Tile tile) {
        foreach (Tile t in tiles) {
            if (t.xPos == tile.xPos && t.yPos == tile.yPos) {
                return true;
            }
        }
        return false;
    }
}
