using System.Collections;
using System.Collections.Generic;
using UnityEngine;


// Interface / Component 
public interface entity_component
{
    // Attributes for Gameplay 
    abstract int HP { get; set; }
    abstract int maxHP { get; set; }
    abstract float power { get; set; }
    abstract float defense { get; set; }
    abstract float dodge { get; set; }
    abstract float accuracy { get; set; }
    abstract float magicDefense { get; set; }
    abstract float magicAccuracy { get; set; }
    abstract float magicPower { get; set; }
    abstract float speed { get; set; }
    abstract List<Action> actions { get; set; }


    //Methods for Gameplay 

    // Attributes for Management  
    abstract Observer observer { get; set; }
    public entity_decorator parent { get; set; }

    // Methods for management 
    abstract string Report();
    public void RemoveCondition(System.Type type);

}

// Decorator Interface
public interface entity_decorator : entity_component
{
    public entity_component child { get; set; }
}
