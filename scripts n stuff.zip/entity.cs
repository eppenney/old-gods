using System.Collections;
using System.Collections.Generic;
using UnityEngine;


// Concrete Component 
public class enemy : entity_component, MonoBeh
{
    // Constructor 
    public enemy()
    {
        observer = GameObject.Find("Observer").GetComponent<Observer>();
        observer.entities.Add(this);
        Debug.Log("Linked with " + observer);
    }

    // Gameplay Attributes
    public int HP { get; set; }
    public int maxHP { get; set; }
    public float power { get; set; }
    public float defense { get; set; }
    public float dodge { get; set; }
    public float accuracy { get; set; }
    public float magicDefense { get; set; }
    public float magicAccuracy { get; set; }
    public float magicPower { get; set; }
    public float speed { get; set; }
    public List<Action> actions { get; set; }

    // Methods for Gameplay 


    // Attributes for Management 
    public Observer observer { get; set; }
    public entity_decorator parent { get; set; }

    // Methods for Management 
    public string Report()
    {
        return "Blargh";
    }

    public void RemoveCondition(System.Type type)
    {
        Debug.Log("No Conditions");
    }
}



public class entity : MonoBehaviour
{
    entity_component lot;
    entity_component slimed_lot;
    // Start is called before the first frame update
    public void Start()
    {
        lot = new enemy();
        //slimed_lot = new slimed(lot);
        lot = new slimed(lot);
    }
}
