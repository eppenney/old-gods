using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Interface / Component 
public interface entity_component
{
    abstract void Link();
    abstract string Report();
    abstract Observer observer {get;set;}
}

// Concrete Component 
public class enemy : entity_component
{
    public enemy() { }
    public Observer observer {get;set;}

    public void Link()
    {
        observer = GameObject.Find("Observer").GetComponent<Observer>();
        observer.entities.Add(this);
        Debug.Log("Linked with " + observer);
    }

    public string Report()
    {
        return "Blargh";
    }
}

// Decorator Interface
public interface entity_decorator : entity_component
{
    public entity_component target { get; set;}
}

// Concrete Decorator 
public class slimed : entity_decorator
{
    public entity_component target { get; set; }
    public Observer observer { get; set; }
    
    public slimed(entity_component targ)
    {
        target = targ;
    }
    
    public void Link()
    {
        observer = GameObject.Find("Observer").GetComponent<Observer>();
        observer.entities.Add(this);
        Debug.Log("Linked with " + observer);
    }

    public string Report()
    {
        return target.Report() + " I am slimed!";
    }

}

public class entity : MonoBehaviour
{
    entity_component lot;
    entity_component slimed_lot;
    // Start is called before the first frame update
    public void Start()
    {
        lot = new enemy();
        lot.Link();
        slimed_lot = new slimed(lot);
        slimed_lot.Link();

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            //Debug.Log(lot.Report());
            //Debug.Log(slimed_lot.Report());
        }
    }
}
